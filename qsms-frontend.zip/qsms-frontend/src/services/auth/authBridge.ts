/**
 * Integration points between the API layer and the future auth module.
 * Nothing is implemented here: with no provider registered, no Authorization header is sent
 * and no unauthorized handling occurs. The future auth module registers its callbacks.
 */
type TokenProvider = () => string | null;
type UnauthorizedHandler = () => void;

let tokenProvider: TokenProvider = () => null;
let unauthorizedHandler: UnauthorizedHandler | null = null;

export const setAccessTokenProvider = (provider: TokenProvider): void => {
  tokenProvider = provider;
};
export const setUnauthorizedHandler = (handler: UnauthorizedHandler | null): void => {
  unauthorizedHandler = handler;
};
export const getAccessToken = (): string | null => tokenProvider();
export const notifyUnauthorized = (): void => unauthorizedHandler?.();
