import axios from 'axios';
import type { ApiFieldErrors } from '@/types';

export type ApiErrorKind =
  | 'network'
  | 'timeout'
  | 'cancelled'
  | 'unauthorized'
  | 'forbidden'
  | 'not_found'
  | 'validation'
  | 'server'
  | 'misconfigured'
  | 'unknown';

export class ApiError extends Error {
  readonly kind: ApiErrorKind;
  readonly status?: number;
  readonly fieldErrors?: ApiFieldErrors;

  constructor(kind: ApiErrorKind, options: { status?: number; fieldErrors?: ApiFieldErrors } = {}) {
    super(kind);
    this.name = 'ApiError';
    this.kind = kind;
    this.status = options.status;
    this.fieldErrors = options.fieldErrors;
  }

  /** i18n key in the `errors` namespace. Raw server messages are never shown to users. */
  get messageKey(): string {
    return `errors:${this.kind}`;
  }
}

const kindFromStatus = (status: number): ApiErrorKind => {
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not_found';
  if (status === 400 || status === 422) return 'validation';
  if (status >= 500) return 'server';
  return 'unknown';
};

/**
 * Best-effort extraction of `{ errors: { field: string | string[] } }`.
 * Provisional until the real backend error contract is confirmed from the OpenAPI spec.
 */
const extractFieldErrors = (data: unknown): ApiFieldErrors | undefined => {
  if (!data || typeof data !== 'object') return undefined;
  const errors = (data as { errors?: unknown }).errors;
  if (!errors || typeof errors !== 'object' || Array.isArray(errors)) return undefined;
  const result: ApiFieldErrors = {};
  for (const [field, value] of Object.entries(errors)) {
    if (typeof value === 'string') result[field] = [value];
    else if (Array.isArray(value)) result[field] = value.filter((v): v is string => typeof v === 'string');
  }
  return Object.keys(result).length ? result : undefined;
};

export function normalizeApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error;
  if (axios.isCancel(error)) return new ApiError('cancelled');
  if (axios.isAxiosError(error)) {
    if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') return new ApiError('timeout');
    if (!error.response) return new ApiError('network');
    const { status, data } = error.response;
    return new ApiError(kindFromStatus(status), { status, fieldErrors: extractFieldErrors(data) });
  }
  return new ApiError('unknown');
}
