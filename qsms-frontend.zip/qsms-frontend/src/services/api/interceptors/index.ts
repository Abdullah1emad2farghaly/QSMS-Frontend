import type { AxiosInstance } from 'axios';
import { env } from '@/app/config';
import { usePreferencesStore } from '@/store';
import { getAccessToken, notifyUnauthorized } from '@/services/auth';
import { ApiError, normalizeApiError } from '../errors';

export function registerInterceptors(client: AxiosInstance): void {
  client.interceptors.request.use((config) => {
    if (!env.apiBaseUrl) throw new ApiError('misconfigured');

    config.headers.set('Accept-Language', usePreferencesStore.getState().language);
    const token = getAccessToken();
    if (token) config.headers.set('Authorization', `Bearer ${token}`);
    return config;
  });

  client.interceptors.response.use(
    (response) => response,
    (error: unknown) => {
      const apiError = normalizeApiError(error);
      if (apiError.kind === 'unauthorized') notifyUnauthorized(); // refresh workflow plugs in here later
      return Promise.reject(apiError);
    },
  );
}
