import axios, { type AxiosRequestConfig } from 'axios';
import { env } from '@/app/config';
import { registerInterceptors } from '../interceptors';

export const httpClient = axios.create({
  baseURL: env.apiBaseUrl || undefined,
  timeout: env.apiTimeoutMs,
  headers: { Accept: 'application/json' },
});

registerInterceptors(httpClient);

/**
 * Typed request helper returning the response body.
 * Cancellation: pass `signal` from an AbortController.
 * Failures always reject with an `ApiError`.
 */
export async function request<T>(config: AxiosRequestConfig): Promise<T> {
  const response = await httpClient.request<T>(config);
  return response.data;
}
