/**
 * Role groups mirroring the approved `pages/` structure.
 * Provisional: reconcile with the backend role model once the OpenAPI spec is reviewed.
 */
export const USER_ROLES = [
  'main_admin',
  'school_managers',
  'parents',
  'collectors',
  'testers',
  'teachers',
] as const;
export type UserRole = (typeof USER_ROLES)[number];
