export type ApiFieldErrors = Record<string, string[]>;
