import { useTranslation } from 'react-i18next';
import styles from './LandingPage.module.css';

export default function LandingPage() {
  const { t } = useTranslation();
  return (
    <section className={styles.hero}>
      <h1 className={styles.title}>{t('app.title')}</h1>
      <p className={styles.status}>{t('landing.status')}</p>
    </section>
  );
}
