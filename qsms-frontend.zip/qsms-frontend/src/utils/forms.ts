import type { FieldValues, Path, UseFormSetError } from 'react-hook-form';
import type { ApiError } from '@/services/api';

/** Maps backend field errors (when present) onto a react-hook-form instance. */
export function applyApiFieldErrors<T extends FieldValues>(
  error: ApiError,
  setError: UseFormSetError<T>,
): void {
  for (const [field, messages] of Object.entries(error.fieldErrors ?? {})) {
    setError(field as Path<T>, { type: 'server', message: messages[0] });
  }
}
