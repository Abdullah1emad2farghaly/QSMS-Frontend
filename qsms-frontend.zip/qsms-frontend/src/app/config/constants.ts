export const SUPPORTED_LANGUAGES = ['ar', 'en'] as const;
export type Language = (typeof SUPPORTED_LANGUAGES)[number];

export const LANGUAGE_DIRECTION: Record<Language, 'rtl' | 'ltr'> = { ar: 'rtl', en: 'ltr' };

export const THEME_PREFERENCES = ['light', 'dark', 'system'] as const;
export type ThemePreference = (typeof THEME_PREFERENCES)[number];

export const STORAGE_KEYS = {
  preferences: 'qsms.preferences',
} as const;
