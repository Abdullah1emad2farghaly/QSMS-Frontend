import { SUPPORTED_LANGUAGES, type Language } from './constants';

const raw = import.meta.env;

const toPositiveNumber = (value: unknown, fallback: number): number => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

const toLanguage = (value: unknown): Language =>
  SUPPORTED_LANGUAGES.includes(value as Language) ? (value as Language) : 'ar';

/** Single access point for environment configuration. Only VITE_* values are exposed. */
export const env = {
  mode: raw.MODE,
  isDev: raw.DEV,
  isProd: raw.PROD,
  apiBaseUrl: String(raw.VITE_API_BASE_URL ?? '').trim().replace(/\/+$/, ''),
  apiTimeoutMs: toPositiveNumber(raw.VITE_API_TIMEOUT_MS, 30_000),
  defaultLanguage: toLanguage(raw.VITE_DEFAULT_LANGUAGE),
} as const;
