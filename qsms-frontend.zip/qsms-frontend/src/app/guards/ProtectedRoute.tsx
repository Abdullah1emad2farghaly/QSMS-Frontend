import { Navigate, Outlet } from 'react-router-dom';

interface ProtectedRouteProps {
  /** Access decision supplied by the future auth/permission module. */
  isAllowed: boolean;
  redirectTo: string;
}

/**
 * Infrastructure only: it makes no authentication decision itself.
 * It is not applied to any route yet because no protected routes exist.
 */
export function ProtectedRoute({ isAllowed, redirectTo }: ProtectedRouteProps) {
  return isAllowed ? <Outlet /> : <Navigate to={redirectTo} replace />;
}
