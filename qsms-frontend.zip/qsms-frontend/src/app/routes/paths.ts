export const ROUTES = {
  root: '/',
} as const;
