import { createBrowserRouter, type RouteObject } from 'react-router-dom';
import { ProtectedRoute } from '@/app/guards/ProtectedRoute';
import { PublicLayout } from '@/app/layouts/PublicLayout';
import { LoadingScreen } from '@/components/feedback/LoadingScreen';
import { RouteError } from '@/components/feedback/RouteError';
import { ROUTES } from './paths';
import { notFoundRoute, protectedRoutes, publicRoutes } from './routes';

// Wrapped only when protected routes exist. `isAllowed={false}` is a deny-by-default
// placeholder until the auth module supplies a real decision.
const protectedGroup: RouteObject[] = protectedRoutes.length
  ? [{ element: <ProtectedRoute isAllowed={false} redirectTo={ROUTES.root} />, children: protectedRoutes }]
  : [];

export const router = createBrowserRouter([
  {
    element: <PublicLayout />,
    errorElement: <RouteError />,
    hydrateFallbackElement: <LoadingScreen />,
    children: [...publicRoutes, ...protectedGroup, notFoundRoute],
  },
]);
