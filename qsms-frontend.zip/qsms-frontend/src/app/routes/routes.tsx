import type { ComponentType } from 'react';
import type { LazyRouteFunction, RouteObject } from 'react-router-dom';

/** Lazy-load a page module whose default export is the page component. */
export const lazyPage =
  (loader: () => Promise<{ default: ComponentType }>): LazyRouteFunction<RouteObject> =>
  async () => ({ Component: (await loader()).default });

export const publicRoutes: RouteObject[] = [
  { index: true, lazy: lazyPage(() => import('@/pages/public/LandingPage')) },
];

/** Routes requiring authentication/roles/permissions. Empty until those modules exist. */
export const protectedRoutes: RouteObject[] = [];

export const notFoundRoute: RouteObject = {
  path: '*',
  lazy: lazyPage(() => import('@/pages/public/NotFoundPage')),
};
