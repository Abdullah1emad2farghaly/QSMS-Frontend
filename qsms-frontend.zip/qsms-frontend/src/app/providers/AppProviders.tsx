import { Suspense, type ReactNode } from 'react';
import { I18nextProvider } from 'react-i18next';
import { ErrorBoundary } from '@/components/feedback/ErrorBoundary';
import { LoadingScreen } from '@/components/feedback/LoadingScreen';
import { usePreferencesSync } from '@/hooks/usePreferencesSync';
import i18n from '@/translation/i18n';

function PreferencesSync() {
  usePreferencesSync();
  return null;
}

/** Provider order (outer → inner): ErrorBoundary → i18n → Suspense. Zustand needs no provider. */
export function AppProviders({ children }: { children: ReactNode }) {
  return (
    <ErrorBoundary>
      <I18nextProvider i18n={i18n}>
        <PreferencesSync />
        <Suspense fallback={<LoadingScreen />}>{children}</Suspense>
      </I18nextProvider>
    </ErrorBoundary>
  );
}
