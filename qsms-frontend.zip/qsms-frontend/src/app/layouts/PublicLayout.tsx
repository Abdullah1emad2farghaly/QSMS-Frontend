import { Outlet } from 'react-router-dom';
import { LanguageSwitcher } from '@/components/common/LanguageSwitcher';
import { ThemeToggle } from '@/components/common/ThemeToggle';
import styles from './PublicLayout.module.css';

/** Public shell. Auth, main-app and role layouts are added beside it when those modules start. */
export function PublicLayout() {
  return (
    <div className={styles.shell}>
      <header className={styles.header}>
        <ThemeToggle />
        <LanguageSwitcher />
      </header>
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}
