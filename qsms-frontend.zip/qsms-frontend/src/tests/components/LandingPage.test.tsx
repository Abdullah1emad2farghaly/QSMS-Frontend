import { act, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import LandingPage from '@/pages/public/LandingPage';
import i18n from '@/translation/i18n';

describe('LandingPage', () => {
  it('renders the English title and status message', async () => {
    await act(() => i18n.changeLanguage('en'));
    render(<LandingPage />);
    expect(screen.getByRole('heading', { name: 'Quran School Management System' })).toBeInTheDocument();
    expect(screen.getByText(/currently under development/i)).toBeInTheDocument();
  });

  it('renders Arabic content', async () => {
    await act(() => i18n.changeLanguage('ar'));
    render(<LandingPage />);
    expect(screen.getByRole('heading', { name: 'نظام إدارة مدرسة القرآن' })).toBeInTheDocument();
  });
});
