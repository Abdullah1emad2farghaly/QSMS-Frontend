import { AxiosError } from 'axios';
import { describe, expect, it } from 'vitest';
import { ApiError, normalizeApiError } from '@/services/api';

describe('normalizeApiError', () => {
  it('maps timeouts', () => {
    expect(normalizeApiError(new AxiosError('t', 'ECONNABORTED')).kind).toBe('timeout');
  });

  it('maps missing responses to network errors', () => {
    expect(normalizeApiError(new AxiosError('n', 'ERR_NETWORK')).kind).toBe('network');
  });

  it('maps 422 with field errors to validation', () => {
    const err = new AxiosError('v', 'ERR_BAD_REQUEST', undefined, undefined, {
      status: 422,
      data: { errors: { email: ['bad'] } },
    } as never);
    const result = normalizeApiError(err);
    expect(result.kind).toBe('validation');
    expect(result.fieldErrors).toEqual({ email: ['bad'] });
  });

  it('passes ApiError through and handles unknown values', () => {
    const original = new ApiError('server', { status: 500 });
    expect(normalizeApiError(original)).toBe(original);
    expect(normalizeApiError('x').kind).toBe('unknown');
  });
});
