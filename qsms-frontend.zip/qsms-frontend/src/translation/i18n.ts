import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { SUPPORTED_LANGUAGES } from '@/app/config';
import { usePreferencesStore } from '@/store';
import arCommon from './ar/common.json';
import arErrors from './ar/errors.json';
import arValidation from './ar/validation.json';
import enCommon from './en/common.json';
import enErrors from './en/errors.json';
import enValidation from './en/validation.json';

export const defaultNS = 'common';

void i18n.use(initReactI18next).init({
  resources: {
    ar: { common: arCommon, errors: arErrors, validation: arValidation },
    en: { common: enCommon, errors: enErrors, validation: enValidation },
  },
  lng: usePreferencesStore.getState().language,
  fallbackLng: 'en',
  supportedLngs: [...SUPPORTED_LANGUAGES],
  ns: ['common', 'errors', 'validation'],
  defaultNS,
  interpolation: { escapeValue: false },
  returnNull: false,
  initImmediate: false,
  react: { useSuspense: false },
});

export default i18n;
