# QSMS Frontend — Foundation

React 18 + TypeScript (strict) + Vite. Foundation only: no business modules.

## Run
```bash
npm install
cp .env.example .env.local   # leave VITE_API_BASE_URL empty until the real URL is known
npm run dev
npm run build
npm test                     # unit + component (Vitest)
npx playwright install && npm run test:e2e
```

## Layout
Approved `src/` structure is preserved (app, services, hooks, store, utils, types, schemas,
components, pages with 7 groups, translation ar/en, styles, assets, tests). Additions:
`app/guards`, `services/api/{client,interceptors,endpoints}`, `components/feedback`, `pages/public`,
`styles/{tokens,themes}`, `assets/{images,icons,fonts}`.

## Conventions
- Default language Arabic (RTL); English (LTR). Preferences persist in localStorage.
- API: use `request<T>()` from `@/services/api`; errors are always `ApiError`.
- Auth plugs in via `services/auth/authBridge.ts` (token provider, unauthorized handler).
- Pages are lazy: default export + entry in `app/routes/routes.tsx`.
- Endpoints go in `services/api/endpoints/` only after being confirmed from the OpenAPI spec.
